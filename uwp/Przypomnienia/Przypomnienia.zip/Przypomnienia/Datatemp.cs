﻿using System;

public class Class1
{
	public Class1()
	{
	}
}
