#include <iostream>

using namespace std;

int * alokuj(){
    return new int;
}

int main(){
    
    cin.get();
    return 0;
}