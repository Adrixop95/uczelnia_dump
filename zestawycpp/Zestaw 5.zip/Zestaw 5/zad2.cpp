#include <iostream>

using namespace std;

struct lista{
    int i;
    
    struct lista * wsk;
};

int main(){
    
    cin.get();
    return 0;
}