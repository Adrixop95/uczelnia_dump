#include <iostream>

using namespace std;

struct trojkat{
    double a,h;
};

struct prostokat{
    double a,b;
};

struct trapez{
    double a,b,h;
};

union wymiary{
    struct trojkat troj, rown;
    struct prostokat prost;
    struct trapez trap;
};

struct figura{
    union wymiary wym;
    int fig;
};

double pole(struct figura f){
    switch (f.fig){
        case 0: return f.wym.troj.a*f.wym.troj.h/2;
        case 1: return f.wym.prost.a*f.wym.prost.b;
        case 2: return f.wym.rown.a*f.wym.rown.h;
        case 3: return f.wym.trap.h*(f.wym.trap.a+f.wym.trap.b)/2;
    }
}

int main(){
    
    cin.get();
    return 0;
}