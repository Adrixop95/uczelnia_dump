#include <iostream>

using namespace std;

void wczytaj(struct dane_osobwe tab[], int n){
    int i, d;
    
    for (i = 0; i < n; i++){
        cout <<"Czy teraz wpisujesz dane osobne kobiety (1) czy mężczyny (2)?" << endl;
        cin >> d;
        
        if (d == 1){
            tab[i].plec=kobieta;
        } else {
            tab[i].plec=mezczyzna;
        }
        
        cout << "Podaj imie" << endl;
        cin >> tab[i].imie;
        
        cout << "Podaj nazwysko" << endl;
        cin >> tab[i].nazwisko;
        
        cout << "Podaj stan cywilny" << endl;
        
        if (tab[i].plec==kobieta){
            cout << "Wolna (0), mezatka (1)" << endl;
            cin >> d;
            
            if (d == 0){
                tab[i].stan_cywilny.k=wolna;
            } else {
                tab[i].stan_cywilny.k=mezatka;
            }
        } else {
            cout << "Wolny (=), zonaty (1)" << endl;
            cin >> d;
            
            if (d == 0){
                tab[i].stan_cywilny.m=wolny;
            } else {
                tab[i].stan_cywilny.m=zonaty'
            }
        }
    }
}

int main(){
    
    cin.get();
    return 0;
}