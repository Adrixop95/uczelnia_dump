#include <iostream>

using namespace std;

class liczba{
private:
    int wart_licz;
    
public:
    void wczytaj();
    void wypisz();
    void nadaj_w(int);
    int wartosc();
    unsigned int abs();
};

void liczba::wczytaj(){
    cout << "Podaj wartosc liczby : " << endl;
    cin >> wart_licz;
}

void liczba::wypisz(){
    cout << "Przechowywana liczba to: " << wart_licz << endl;
}

void liczba::nadaj_w(int n){
    wart_licz = n;
}

int liczba::wartosc(){
    return wart_licz;
}

unsigned int liczba::abs(){
    if (wart_licz >= 0){
        return wart_licz;
    } else {
        return -wart_licz;
    }
}

int main(){
    
    liczba licz;
    int n = 0;
    
    licz.wczytaj();
    licz.wypisz();
    licz.nadaj_w(n);
    licz.wartosc();
    licz.abs();
    
    cin.get();
    return 0;
}